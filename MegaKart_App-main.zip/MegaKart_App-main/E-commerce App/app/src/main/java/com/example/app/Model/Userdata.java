package com.example.app.Model;

public class Userdata {
    public String name,email,phone,password;

    public Userdata() {

    }

    public Userdata(String name, String email, String phone) {
        this.name = name;
        this.email = email;
        this.phone = phone;
    }

}
