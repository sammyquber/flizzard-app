package com.example.app.Model;

public class AllCategoriesData {

    public CharSequence title;
    public int image;
    public CharSequence disc;

    public AllCategoriesData(CharSequence title,CharSequence disc, int image) {
        this.title = title;
        this.image = image;
        this.disc=disc;
    }
}
